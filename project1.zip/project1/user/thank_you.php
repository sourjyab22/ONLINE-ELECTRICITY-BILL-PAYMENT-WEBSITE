<html>
    <head>
        <title>thank you</title>
        <link rel="stylesheet" href="main1.css">
</head>
<body>
    <div class="cointainer">
        <img src="accept.png " width=50>
        <p style=font-size:x-large>Thank You, Your payment has been successfully submitted</p>

<a href="paid_table.php">OK</a>
</div>
</body>
<html>
