<?php
#define("API_KEY", 'NmY1NDc1Njk3Mzc3NjQ2MTM5NjIzNDcyNzg2ZTY3NTc=');
#define("MOBILE", '');

?>